rm(list=ls());

install.packages("ElemStatLearn");
install.packages("class");
install.packages("glmnet");
install.packages("pls");
install.packages("leaps");
install.packages("randomForest")

setwd("D:\\RCodes\\Assignment5");

library(ElemStatLearn);
library(class);
library(glmnet);
library(pls);
library(leaps);
library(randomForest);

data("spam");
head(spam);

##As the data are not spread correctly we will shuffle the set completely
spam<-spam[sample(nrow(spam)),];

spami=grep("spam",colnames(spam))

for (o in 1:nrow(spam)) {
  if(spam[o,spami]=="spam"){
    spam[o,spami+1] = 2
  }else{
    spam[o,spami+1] = 3
  }
}

spam<-subset(spam,select = -spam)


##Now dividing the dataset into Training and test Data for the original set we have:
set.seed(1);
vars=c("A.1","A.2","A.3","A.4","A.5","A.6","A.7","A.8","A.9","A.10","A.11","A.12","A.13","A.14","A.15","A.16","A.17","A.18","A.19","A.20","A.21","A.22","A.23","A.24","A.25","A.26","A.27","A.28","A.29","A.30","A.31","A.32","A.33","A.34","A.35","A.36","A.37","A.38","A.39","A.40","A.41","A.42","A.43","A.44","A.45","A.46","A.47","A.48","A.49","A.50","A.51","A.52","A.53","A.54","A.55","A.56","A.57","V59");
tupleSelc=sample(x=nrow(spam), size=0.55*nrow(spam))
trnset=spam[tupleSelc,vars]
tstset=spam[-tupleSelc,vars]


##Now dividing the dataset into Training and test Data with the oulier:
#Draing of plots to see which factors are standing apart as differenciators in the type desicion

par(mfrow=c(8,7)) #13 graphs
for(i in names(spam)){
  plot(eval(parse(text=i)) ~ V59, data = spam, xlab="V59", ylab=i)
}

spam2<-spam
spam2[5,1]=10
tupleSelc_oulier=sample(x=nrow(spam2), size=0.55*nrow(spam2))
trnset_outlier=spam[tupleSelc_oulier,vars]
tstset_outlier=spam[-tupleSelc_oulier,vars]

set.seed(1);

install.packages("neuralnet")
install.packages("Metrics")

library(neuralnet)
library(Metrics)

n<-names(spam)
f <- as.formula(paste("V59 ~", paste(n[!n %in% "V59"], collapse = " + ")))

##Using the idea from the Q2 we will take number of hhidden neurons to be 6.
nn.6.original <- neuralnet(V59 ~ A.1 + A.2 + A.3 + A.4 + A.5 + A.6 + A.7 + A.8 + A.9 + A.10 + 
                      A.11 + A.12 + A.13 + A.14 + A.15 + A.16 + A.17 + A.18 + A.19 + 
                      A.20 + A.21 + A.22 + A.23 + A.24 + A.25 + A.26 + A.27 + A.28 + 
                      A.29 + A.30 + A.31 + A.32 + A.33 + A.34 + A.35 + A.36 + A.37 + 
                      A.38 + A.39 + A.40 + A.41 + A.42 + A.43 + A.44 + A.45 + A.46 + 
                      A.47 + A.48 + A.49 + A.50 + A.51 + A.52 + A.53 + A.54 + A.55 + 
                      A.56 + A.57
                    , data=trnset
                    , hidden=1
                    , stepmax = 1e+09
                    , linear.output=TRUE)

nn.6.outlier <- neuralnet(V59 ~ A.1 + A.2 + A.3 + A.4 + A.5 + A.6 + A.7 + A.8 + A.9 + A.10 + 
                             A.11 + A.12 + A.13 + A.14 + A.15 + A.16 + A.17 + A.18 + A.19 + 
                             A.20 + A.21 + A.22 + A.23 + A.24 + A.25 + A.26 + A.27 + A.28 + 
                             A.29 + A.30 + A.31 + A.32 + A.33 + A.34 + A.35 + A.36 + A.37 + 
                             A.38 + A.39 + A.40 + A.41 + A.42 + A.43 + A.44 + A.45 + A.46 + 
                             A.47 + A.48 + A.49 + A.50 + A.51 + A.52 + A.53 + A.54 + A.55 + 
                             A.56 + A.57
                           , data=trnset_outlier
                           , hidden=1
                           , stepmax = 1e+09
                           , linear.output=TRUE)

spam_original.preds.scaled <- round(neuralnet::compute(nn.6.original, tstset[,1:57],rep = 1)$net.result[,1])
spam_oulier.preds.scaled <- round(neuralnet::compute(nn.6.outlier, tstset[,1:57],rep = 1)$net.result[,1])

original6err<-rmse(tstset$V59, spam_original.preds.scaled)
outlier6err<-rmse(tstset$V59, spam_oulier.preds.scaled)

original6err

outlier6err

##From the above observations we note that the effect of the outlier changes accordingly,adding the error by 0.38 and similarly the effect.

val_Of_zero_effect=0

for (i in 10:0.25) {
  spam2[5,1]=i
  tupleSelc_oulier=sample(x=nrow(spam2), size=0.55*nrow(spam2))
  trnset_outlier=spam[tupleSelc_oulier,vars]
  tstset_outlier=spam[-tupleSelc_oulier,vars]

  nn.6.outlier <- neuralnet(V59 ~ A.1 + A.2 + A.3 + A.4 + A.5 + A.6 + A.7 + A.8 + A.9 + A.10 + 
                              A.11 + A.12 + A.13 + A.14 + A.15 + A.16 + A.17 + A.18 + A.19 + 
                              A.20 + A.21 + A.22 + A.23 + A.24 + A.25 + A.26 + A.27 + A.28 + 
                              A.29 + A.30 + A.31 + A.32 + A.33 + A.34 + A.35 + A.36 + A.37 + 
                              A.38 + A.39 + A.40 + A.41 + A.42 + A.43 + A.44 + A.45 + A.46 + 
                              A.47 + A.48 + A.49 + A.50 + A.51 + A.52 + A.53 + A.54 + A.55 + 
                              A.56 + A.57
                            , data=trnset_outlier
                            , hidden=1
                            , stepmax = 1e+09
                            , linear.output=TRUE)
  
  spam_oulier.preds.scaled <- round(neuralnet::compute(nn.6.outlier, tstset[,1:57],rep = 1)$net.result[,1])
  outlier6err<-rmse(tstset$V59, spam_oulier.preds.scaled)
  
  if(outlier6err==original6err){
    val_Of_zero_effect=i;
  }
}

val_Of_zero_effect

##Thus at value of outlier set at 10 from original at 0.25 at value of outlier=0 the effect of if vanises