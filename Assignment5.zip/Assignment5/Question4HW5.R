rm(list=ls());

install.packages("ISLR");
install.packages("class");
install.packages("glmnet");
install.packages("pls");
install.packages("leaps");
install.packages("randomForest")

setwd("D:\\RCodes\\Assignment5");

library(ISLR);
library(class);
library(glmnet);
library(pls);
library(leaps);
library(randomForest)

data(OJ)
str(OJ)


##Now dividing the dataset into Training and test Data for the original set we have:
set.seed(1);
vars=c("Purchase","WeekofPurchase","StoreID","PriceCH","PriceMM","DiscCH","DiscMM","SpecialCH","SpecialMM","LoyalCH","SalePriceMM","SalePriceCH","PriceDiff","Store7","PctDiscMM","PctDiscCH","ListPriceDiff","STORE");
tupleSelc=sample(x=nrow(OJ), size=0.55*nrow(OJ))
trnset=OJ[tupleSelc,vars]
tstset=OJ[-tupleSelc,vars]

##Applying the model we get:
install.packages("e1071")

library(e1071)

svm_Model <- svm(Purchase~.,data = trnset)
summary(svm_Model)

cost_Var<-0.01:10
testErr<-numeric(length = length(cost_Var))
trnErr<-numeric(length = length(cost_Var))

for (i in cost_Var) {
  svm_Model_Loop <- svm(Purchase~.,data = trnset, kernel="linear", cost = i)
  
  test_pred<-predict(svm_Model_Loop, newdata = tstset)
  train_pred<-predict(svm_Model_Loop, newdata = trnset)
  
  testErr[i]<-rmse(summary(tstset$Purchase),summary(test_pred))
  trnErr[i]<-rmse(summary(trnset$Purchase),summary(train_pred))
}

testErr

##Plotting of the errors

par(mfrow=c(1,2)) #13 graphs
plot(cost_Var,testErr,ann=FALSE,type="l",xlab = "COST",ylab = "testErr")
plot(cost_Var,trnErr,ann=FALSE, type="l",xlab = "COST",ylab = "trainErr")

##According to the test Error the optimal cost is 1,2,3


##Using the above code for radial kernel

cost_Var<-0.01:10
testErr<-numeric(length = length(cost_Var))
trnErr<-numeric(length = length(cost_Var))

for (i in cost_Var) {
  svm_Model_Loop <- svm(Purchase~.,data = trnset, kernel="radial", cost = i)
  
  test_pred<-predict(svm_Model_Loop, newdata = tstset)
  train_pred<-predict(svm_Model_Loop, newdata = trnset)
  
  testErr[i]<-rmse(summary(tstset$Purchase),summary(test_pred))
  trnErr[i]<-rmse(summary(trnset$Purchase),summary(train_pred))
}

testErr

##Plotting of the errors

par(mfrow=c(1,2)) #13 graphs
plot(cost_Var,testErr,ann=FALSE,type="l",xlab = "COST",ylab = "testErr")
plot(cost_Var,trnErr,ann=FALSE, type="l",xlab = "COST",ylab = "trainErr")

#Here the optimal cost was found to be 3 in test error case

##Repeating the above procedure for the degree 2 
cost_Var<-0.01:10
testErr<-numeric(length = length(cost_Var))
trnErr<-numeric(length = length(cost_Var))

for (i in cost_Var) {
  svm_Model_Loop <- svm(Purchase~.,data = trnset, degree=2 , cost = i)
  
  test_pred<-predict(svm_Model_Loop, newdata = tstset)
  train_pred<-predict(svm_Model_Loop, newdata = trnset)
  
  testErr[i]<-rmse(summary(tstset$Purchase),summary(test_pred))
  trnErr[i]<-rmse(summary(trnset$Purchase),summary(train_pred))
}

testErr

##Plotting of the errors

par(mfrow=c(1,2)) #13 graphs
plot(cost_Var,testErr,ann=FALSE,type="l",xlab = "COST",ylab = "testErr")
plot(cost_Var,trnErr,ann=FALSE, type="l",xlab = "COST",ylab = "trainErr")
