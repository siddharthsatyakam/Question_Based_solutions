rm(list=ls());

install.packages("ElemStatLearn");
install.packages("class");
install.packages("glmnet");
install.packages("pls");
install.packages("leaps");
install.packages("randomForest")

setwd("D:\\RCodes\\Assignment5");

library(ElemStatLearn);
library(class);
library(glmnet);
library(pls);
library(leaps);
library(randomForest);


##Importing of the data into the R
load("D:\\RCodes\\Assignment5\\SwissBankNotes.rdata")


##Now dividing the dataset into Training and test Data for the original set we have:
set.seed(1);
vars=c("length","height.left","height.right","inner.lower","inner.upper","diagonal");
tupleSelc=sample(x=nrow(SwissBankNotes), size=0.5*nrow(SwissBankNotes))
trnset=SwissBankNotes[tupleSelc,vars]
tstset=SwissBankNotes[-tupleSelc,vars]

##Applying the prcomp() ,i.e. the PCA based model:
swissNotes_PCA<-prcomp(trnset,scale. = T)
summary(swissNotes_PCA)

swissNotes_PCA<-prcomp(tstset,scale. = T)
summary(swissNotes_PCA)

swissNotes_PCA<-prcomp(SwissBankNotes,scale. = T)
summary(swissNotes_PCA)
