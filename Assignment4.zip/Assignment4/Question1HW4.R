rm(list=ls());

install.packages("ElemStatLearn");
install.packages("class");
install.packages("glmnet");
install.packages("pls");
install.packages("leaps");


library("ElemStatLearn");
library("glmnet");
library("pls");
library("leaps");

setwd("D:\\RCodes\\Assignment4");

data(prostate)


##Draing of plots to see which factors are standing apart as differenciators in the type desicion
par(mfrow=c(2,5)) #13 graphs
for(i in names(prostate)){
  plot(eval(parse(text=i)) ~ lpsa, data = prostate, xlab(lpsa), ylab=i)
}


##Setting variables for testing
set.seed(1);
vars=c("lcavol","lweight","age","lbph","svi","lcp","gleason","pgg45","lpsa","train");
tupleSelc=sample(x=nrow(prostate), size=0.60*nrow(prostate))
trnset=prostate[tupleSelc,vars]
tstset=prostate[-tupleSelc,vars]

##Applying the best Subset selection on the whole data
bestSubOut=regsubsets(lpsa~.,data=prostate,method = "exhaustive")

bestSubSummary=summary(bestSubOut)

#To check whether the given the given model is a gussian or not,so as to use the CP
hist(prostate$lpsa)

#Calculating the AIC:
bestSubSummary$cp

#Calculating the BIC:
bestSubSummary$bic



##From the analysis of the independent graphs of attributes wrt to the lpsa we are removing the age,lbph,gleson,pgg45,train from the model as these don't show any correlation with lpsa
set.seed(1);
vars=c("lcavol","lweight","svi","lcp","lpsa");
tupleSelc=sample(x=nrow(prostate), size=0.60*nrow(prostate))
trnset=prostate[tupleSelc,vars]
tstset=prostate[-tupleSelc,vars]

##Applying the best Subset selection on the whole data
bestSubOut=regsubsets(lpsa~.,data=trnset,method = "exhaustive")

bestSubSummary=summary(bestSubOut)

#To check whether the given the given model is a gussian or not,so as to use the CP
hist(prostate$lpsa)

#Calculating the AIC:
bestSubSummary$cp

#Calculating the BIC:
bestSubSummary$bic

newWorkSet<-prostate[vars];

##Reframing of the training and Test dataset:
set.seed(1);
vars=c("lcavol","lweight","svi","lcp","lpsa");
tupleSelc=sample(x=nrow(newWorkSet), size=0.60*nrow(newWorkSet))
trnset=newWorkSet[tupleSelc,vars]
tstset=newWorkSet[-tupleSelc,vars]


### cv
library(leaps)
## 5 fold

####Cross validation code used from https://sphhp.buffalo.edu/content/sphhp/biostatistics/news-events/workshops/cdse-r-workshop/_jcr_content/par/download_9/file.res/prostate_demo.R by Rachel Hageman
predict.regsubsets = function(object, newdata, id, ...){
  temp_X <- cbind(rep(1, length(newdata[,1])), newdata)
  colnames(temp_X) <- c("(Intercept)", colnames(newdata))
  
  coefi = coef(object, id=i)
  my_pred = as.matrix(temp_X[ ,names(coefi)])%*%coefi
  
  return(my_pred)
}

k=5
set.seed(1)
folds = sample(1:k,nrow(newWorkSet), replace=TRUE)
cv.errors=matrix(NA, k, 4, dimnames=list(NULL, paste(1:4)))

for(j in 1:k){
  best_fit=regsubsets(lpsa ~ ., data = newWorkSet[folds!=j,], nvmax = 4)
  summary(best_fit)
  for(i in 1:4){
    pred=predict(best_fit, newdata = newWorkSet[folds==j,], id=i)
    cv.errors[j,i]=mean((newWorkSet$lpsa[folds==j]-pred)^2)
  }
}

mean.cv.errors=apply(cv.errors,2,mean)
mean.cv.errors

k=10
set.seed(1)
folds = sample(1:k,nrow(newWorkSet), replace=TRUE)
cv.errors=matrix(NA, k, 4, dimnames=list(NULL, paste(1:4)))

for(j in 1:k){
  best_fit=regsubsets(lpsa ~ ., data = newWorkSet[folds!=j,], nvmax = 4)
  summary(best_fit)
  for(i in 1:4){
    pred=predict(best_fit, newdata = newWorkSet[folds==j,], id=i)
    cv.errors[j,i]=mean((newWorkSet$lpsa[folds==j]-pred)^2)
  }
}

mean.cv.errors=apply(cv.errors,2,mean)
mean.cv.errors


#boot

install.packages("bootstrap")
library(bootstrap)
library(boot)

best_sub = regsubsets(lpsa~.,data = prostate,method="exhaustive")
reg_summary=summary(best_sub)


beta.fit <- function(X,Y){
  lsfit(X,Y)	
}

beta.predict <- function(fit, X){
  cbind(1,X)%*%fit$coef
}

sq.error <- function(Y,Yhat){
  (Y-Yhat)^2
}

select = reg_summary$outmat
error_store <- c()

for (i in 1:8){
  temp <- which(select[i,] == "*")
  res <- bootpred(prostate[,temp], prostate$lpsa, nboot = 50, theta.fit = beta.fit, theta.predict = beta.predict, err.meas = sq.error)
  error_store <- c(error_store, res[[3]])
}