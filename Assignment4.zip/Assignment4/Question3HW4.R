
install.packages("ElemStatLearn");
install.packages("class");
install.packages("glmnet");
install.packages("pls");
install.packages("leaps");
install.packages("lattice");
install.packages("MASS");
install.packages("xlsx")

library("ElemStatLearn");
library("glmnet");
library("pls");
library("leaps");
library(MASS)
library(lattice)

setwd("D:\\RCodes\\Assignment4");

##Reading the data from the Candy Dataset csv file:


CandyPower <- read.table("candy-data.csv", header=TRUE, 
                           sep=",", row.names="competitorname")

CandyPower

##Drawing of plots to see which factors are acting as amajor pattern in any crime type
par(mfrow=c(3,4)) #12 graphs
for(i in names(CandyPower)){
  boxplot(CandyPower$winpercent ~ eval(parse(text=i)), data = CandyPower, xlab=i, ylab(CandyPower$winpercent))
}

#Here we don't see any pattern in the winpercent when we take the sugarConcentration and the pricepercent into consideration,so we can remove them,

winper=grep("winpercent",colnames(CandyPower))
classiwinper=ncol(CandyPower)+1
  
for (k in 1:nrow(CandyPower)) {
  if(CandyPower[k,winper]>80){
    CandyPower[k,classiwinper] = "3"
  }else if(CandyPower[i,winper]<80 && CandyPower[i,winper]>=50){
    CandyPower[k,classiwinper] = "2"
  }else{
    CandyPower[k,classiwinper] = "1"
  }
}

##To do data division for working
set.seed(1);
vars=c("chocolate","fruity","caramel","peanutyalmondy","nougat","crispedricewafer","hard","bar","pluribus","sugarpercent","pricepercent","winpercent");
tupleSelc=sample(x=nrow(CandyPower), size=0.55*nrow(CandyPower))
trnset=CandyPower[tupleSelc,vars]
tstset=CandyPower[-tupleSelc,vars]

##Application of Random Forest:

#Here as the Bagging is a special case of the Random Forest so we will apply it all together
install.packages("randomForest")
library(randomForest)

CandyPower.bag=randomForest(trnset$winpercent~.,data=trnset,mtry=11,importance=TRUE)
CandyPower.bag

##For calculating the mean square error:
predi = predict(CandyPower.bag,newdata=tstset)

summary(predi)

summary(tstset$winpercent)

##Normal Random Forest for comparision by Bagging method

CandyPower.random=randomForest(trnset$winpercent~.,data=trnset,mtry=9,importance=TRUE)
CandyPower.random

predirand = predict(CandyPower.random,newdata=tstset)

summary(predirand)

summary(tstset$winpercent)

##BOOSTING:
install.packages("gbm")
library(gbm)

CandyPower.boost=gbm(trnset$winpercent~.,data=trnset,distribution="gaussian",n.trees=5000,interaction.depth=4)


prediboost=predict(CandyPower.boost,newdata=tstset,n.trees=5000)

summary(prediboost)

summary(tstset$winpercent)

# LOGISTIC REGRESSION
lr.fit <- glm(as.factor(trnset$winpercent) ~ ., data=trnset, family="binomial")
lr.probs <- predict(lr.fit, tstset, type="response")
lr.predc <- ifelse(lr.probs>.5, "1","0")

test.err.lr <- mean(lr.predc!=tstset$winpercent)

test.err.lr

#KNN
library(class)

knn.prediction <- knn(train=trnset, test=tstset, cl=trnset$winpercent, k=1)
test.err.knn_1 <- mean(knn.prediction!=tstset$winpercent)

summary(test.err.knn_1)