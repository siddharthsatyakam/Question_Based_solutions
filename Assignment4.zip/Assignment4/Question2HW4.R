
install.packages("rpart");
install.packages("plotly");
install.packages("rpart.plot");
install.packages("RColorBrewer");
install.packages("rattle");
install.packages("RWeka");

setwd("D:\\RCodes\\Assignment4");

library(rpart);
library(plotly);
library(rpart.plot);
library(RColorBrewer);
library(rattle);
library(RWeka);

##Downloading of the Wine Data

data(wine);
str(wine);

#Reshuffling the wine dataset in df1 so as to train the classifier by taking minimum rows from the begining
wine<-wine[sample(nrow(wine)),];
head(wine);

##Distribution of the training and test data set for further evaluation
set.seed(1);
vars=c("Type","Alcohol","Malic","Ash","Alcalinity","Magnesium","Phenols","Flavanoids","Nonflavanoids","Proanthocyanins","Color","Hue","Dilution","Proline");
tupleSelc=sample(x=nrow(wine), size=0.55*nrow(wine))
trnset=wine[tupleSelc,vars]
tstset=wine[-tupleSelc,vars]

##Draing of plots to see which factors are standing apart as differenciators in the type desicion
par(mfrow=c(3,6)) #13 graphs
for(i in names(wine)){
  plot(eval(parse(text=i)) ~ wine$Type, data = wine, ylab=i,varwidth=T)
}

#Here we saw except for ash concentration there is a stark difference in concentration in all the other attributes for each type.

##Application of the decision trees:
m.rpart1 <- rpart(Type ~. , data = trnset)
m.rpart1

##Prediction of the Type variable:

predTree<-predict(m.rpart1,tstset);
summary(predTree);

summary(tstset$Type);

m.rpart1$cptable

#After seeing the attributes that the model is using for its modelling ,we can remove Ash,ALcalinity as these are not used in the modeling tree.
##Distribution of the training and test data set for further evaluation
set.seed(1);
vars=c("Type","Alcohol","Malic","Magnesium","Phenols","Flavanoids","Nonflavanoids","Proanthocyanins","Color","Hue","Dilution","Proline");
tupleSelc=sample(x=nrow(wine), size=0.55*nrow(wine))
trnset2=wine[tupleSelc,vars]
tstset2=wine[-tupleSelc,vars]

##Application of the decision trees:
m.rpart2 <- rpart(Type ~. , data = trnset2)
m.rpart2

##Prediction of the Type variable:

predTree<-predict(m.rpart2,tstset2);
summary(predTree);

summary(tstset2$Type); 

m.rpart2$cptable


##To increase the model accuracy lets try to remove the magnesium as there is little fluctuation as compared to other attributes here
set.seed(1);
vars=c("Type","Alcohol","Malic","Phenols","Flavanoids","Nonflavanoids","Proanthocyanins","Color","Hue","Dilution","Proline");
tupleSelc=sample(x=nrow(wine), size=0.55*nrow(wine))
trnset3=wine[tupleSelc,vars]
tstset3=wine[-tupleSelc,vars]

##Application of the decision trees:
m.rpart3 <- rpart(Type ~. , data = trnset3)
m.rpart3

##Prediction of the Type variable:

predTree<-predict(m.rpart3,tstset3);
summary(predTree);

summary(tstset3$Type); 

m.rpart3$cptable

##To see the model behaviour due to removal of an important attribute that is being used for splitting
set.seed(1);
vars=c("Type","Malic","Phenols","Flavanoids","Nonflavanoids","Proanthocyanins","Color","Hue","Dilution","Proline");
tupleSelc=sample(x=nrow(wine), size=0.55*nrow(wine))
trnset4=wine[tupleSelc,vars]
tstset4=wine[-tupleSelc,vars]

##Application of the decision trees:
m.rpart4 <- rpart(Type ~. , data = trnset4)
m.rpart4

##Prediction of the Type variable:

predTree<-predict(m.rpart4,tstset4);
summary(predTree);

summary(tstset4$Type); 

m.rpart4$cptable