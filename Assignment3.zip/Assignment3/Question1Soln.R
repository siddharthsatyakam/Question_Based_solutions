rm(list=ls());

install.packages("ISLR");
install.packages("class");

library("ISLR");
library("lattice");
library("MASS");
library("class");

setwd("D:\\RCodes\\Assignment3");

data("Boston")

##Median
Boston$crim01 <- ifelse(Boston$crim > median(Boston$crim), "1", "0");

attach(Boston)

##Testing the way other rows are getting affected by crime rate
par(mfrow=c(2,6))
for(i in names(Boston)){
  # excluding the own crime variables and the chas variable as the tract bounding the river is not a required aspect
  if( grepl(i, pattern="^crim|^chas")){ next}
  boxplot(eval(parse(text=i)) ~ crim01, ylab=i,varwidth=T)
}

##Setting variables for testing
set.seed(1);
vars=c("zn","indus", "nox","rm","age","dis","rad","tax","ptratio","black","lstat","medv","crim01");
tupleSelc=sample(x=nrow(Boston), size=0.55*nrow(Boston))
trnset=Boston[tupleSelc,vars]
tstset=Boston[-tupleSelc,vars]

# LOGISTIC REGRESSION
lr.fit <- glm(as.factor(crim01) ~ ., data=trnset, family="binomial")
lr.probs <- predict(lr.fit, tstset, type="response")
lr.predc <- ifelse(lr.probs>.5, "1","0")

test.err.lr <- mean(lr.predc!=tstset$crim01)

# LINEAR DISCRIMINANT ANALYSIS
lda.fit <- lda(crim01 ~ ., data=trnset)
lda.predc <- predict(lda.fit, tstset)
test.err.lda <- mean(lda.predc$class!=tstset$crim01)

# QUADRATIC DISCRIMINANT ANALYSIS
qda.fit <- qda(crim01 ~ ., data=trnset)
qda.predqr <- predict(qda.fit, tstset)
test.err.qda <- mean(qda.predqr$class!=tstset$crim01)

# KNN-1
knn.prediction <- knn(train=trnset, test=tstset, cl=trnset$crim01, k=1)
test.err.knn_1 <- mean(knn.prediction!=tstset$crim01)

# KNN-CV
err.knn_cv <- rep(NA,9)
for(i in 2:10){
  knn.predcv <- knn(train=trnset, test=tstset, cl=trnset$crim01, k=i)
  err.knn_cv[i-1] <- mean(knn.predcv!=tstset$crim01)
}
test.err_knn_CV <- min(err.knn_cv)

Start1 = data.frame("method"=c("LR", "LDA", "QDA", "KNN-1", "KNN-CV"), test.err=c(test.err.lr, test.err.lda, test.err.qda, test.err.knn_1, test.err_knn_CV))
Start1

##Setting variables for testing
set.seed(1);
vars=c("indus", "nox","age","dis","rad","tax","ptratio","lstat","crim01");
tupleSelc=sample(x=nrow(Boston), size=0.55*nrow(Boston))
trnset=Boston[tupleSelc,vars]
tstset=Boston[-tupleSelc,vars]

# LOGISTIC REGRESSION
lr.fit <- glm(as.factor(crim01) ~ ., data=trnset, family="binomial")
lr.probs <- predict(lr.fit, tstset, type="response")
lr.predc <- ifelse(lr.probs>.5, "1","0")

test.err.lr <- mean(lr.predc!=tstset$crim01)

# LINEAR DISCRIMINANT ANALYSIS
lda.fit <- lda(crim01 ~ ., data=trnset)
lda.predc <- predict(lda.fit, tstset)
test.err.lda <- mean(lda.predc$class!=tstset$crim01)

# QUADRATIC DISCRIMINANT ANALYSIS
qda.fit <- qda(crim01 ~ ., data=trnset)
qda.predqr <- predict(qda.fit, tstset)
test.err.qda <- mean(qda.predqr$class!=tstset$crim01)

# KNN-1
knn.prediction <- knn(train=trnset, test=tstset, cl=trnset$crim01, k=1)
test.err.knn_1 <- mean(knn.prediction!=tstset$crim01)

# KNN-CV
err.knn_cv <- rep(NA,9)
for(i in 2:10){
  knn.predcv <- knn(train=trnset, test=tstset, cl=trnset$crim01, k=i)
  err.knn_cv[i-1] <- mean(knn.predcv!=tstset$crim01)
}
test.err_knn_CV <- min(err.knn_cv)

Start1 = data.frame("method"=c("LR", "LDA", "QDA", "KNN-1", "KNN-CV"), test.err=c(test.err.lr, test.err.lda, test.err.qda, test.err.knn_1, test.err_knn_CV))
Start1